# R2S: minimal reference implementation

This archive implements the residual-coordinate retraction capsule and the
receiver-side grow-only rejection set of Retraction-Ready State Sharing (R2S).
It accompanies the mathematical construction at a fixed linearization.

The release contains the core algorithm, a small deterministic algebraic
validation, and the numerical summary of Table 6 in `table_data/`. It does not
contain the complete network simulator, mission data, full experimental outputs,
or figure-generation code, and does not reproduce the paper's mission-level
experiments.

## Run

Use Python 3.10 or newer:

```bash
python -m pip install -r requirements.txt
python demo.py
```

The demonstration checks all 256 rejection subsets of an eight-factor Gaussian
model against full-model recomputation, then checks duplicated and reordered
rejection messages, epoch isolation, invalid identifiers, and the case with no
eliminated history. It prints relative errors and exits with an exception if a
check fails.

## Interface and assumptions

- `build_capsule(J, h, retained, U, b)` constructs the five blocks `(S, t, V, G, z)`.
- `retract(capsule, rejected)` returns the corrected retained information pair.
- `posterior(S, t)` returns its mean and covariance.
- `Replica(epoch, capsule).merge(epoch, rejected)` combines identifiers by set
  union and evaluates their joint correction from the immutable original capsule.

The full current model includes the pending factors:
`J = J0 + U @ U.T` and `h = h0 + U @ b`, with positive-definite trusted precision
`J0`. Shapes are `J: (N,N)`, `h: (N,d)`, `U: (N,q)`, and `b: (q,d)`.
Factor identifiers are zero-based columns of `U` within one epoch; retained
indices determine the output-state order. Inputs are dense floating-point arrays.

The source solves against the eliminated-history block once to form the capsule.
For rejection set `K`, the receiver solves with `H = I - G[K,K]` and computes
`S_K = S - V_K @ solve(H, V_K.T)` and
`t_K = t - V_K @ solve(H, z_K)`. The implementation uses Cholesky and triangular
solves rather than explicit inverses. Positive definiteness is guaranteed under
the stated trusted-model assumption; Cholesky reports failure if that condition
or numerical conditioning is insufficient.

An epoch names a fixed model and linearization. Inputs, factor validity decisions,
transport, authentication, and epoch creation are responsibilities of the calling
system. The validation model is generated locally with a fixed random seed; no
measurements or identifying metadata are distributed.

## Tabulated simulation results

`table_data/comparison.csv` records the displayed table values;
`comparison_raw.csv` preserves the saved numerical precision. `conditions.json`
defines the scenario, units, and unavailable entries. The small Gaussian model
in `demo.py` verifies the retraction algebra; it is separate from the network
simulations summarized in these CSV files.
