"""Minimal residual-coordinate retraction at a fixed linearization.

The current information model is J = J0 + U U.T, h = h0 + U b.
J0 must be positive definite. Each column of U is one pending factor;
its zero-based column index is its identifier within the epoch.
"""
from dataclasses import dataclass
from operator import index

import numpy as np
from scipy.linalg import cho_factor, cho_solve, solve_triangular


def _symmetric(a):
    return 0.5 * (a + a.T)


def _ids(values, size):
    """Validate before returning the duplicate-free, ordered identifier set."""
    result = tuple(sorted({index(value) for value in values}))
    if any(value < 0 or value >= size for value in result):
        raise ValueError("Identifier does not belong to this epoch")
    return np.asarray(result, dtype=int)


@dataclass(frozen=True)
class Capsule:
    """Immutable retained precision/information and residual-coordinate blocks."""
    S: np.ndarray
    t: np.ndarray
    V: np.ndarray
    G: np.ndarray
    z: np.ndarray

    def __post_init__(self):
        for name in ("S", "t", "V", "G", "z"):
            value = np.array(getattr(self, name), dtype=float, copy=True)
            value.setflags(write=False)
            object.__setattr__(self, name, value)


def build_capsule(J, h, retained, U, b):
    """Construct (S,t,V,G,z) with one Cholesky factorization of the history.

    Shapes: J (N,N), h (N,d), U (N,q), b (q,d). The sequence
    `retained` fixes the output state order; its complement is eliminated.
    The inputs must describe the current model, including pending factors.
    This reference implementation uses dense arrays for clarity.
    """
    J, h, U, b = (np.asarray(a, dtype=float) for a in (J, h, U, b))
    n = J.shape[0]
    if J.shape != (n, n) or h.ndim != 2 or h.shape[0] != n:
        raise ValueError("Incompatible information-model dimensions")
    if U.ndim != 2 or U.shape[0] != n or b.shape != (U.shape[1], h.shape[1]):
        raise ValueError("Incompatible pending-factor dimensions")
    retained = np.asarray([index(value) for value in retained], dtype=int)
    if not retained.size or np.unique(retained).size != retained.size:
        raise ValueError("Retained indices must be nonempty and distinct")
    _ids(retained, n)
    history = np.setdiff1d(np.arange(n), retained)
    A = J[np.ix_(retained, retained)]
    P = U[retained]
    if not history.size:
        return Capsule(A, h[retained], P, np.zeros((U.shape[1], U.shape[1])), b)
    E = J[np.ix_(retained, history)]
    C = J[np.ix_(history, history)]
    Q, c = U[history], h[history]
    factor = cho_factor(C, lower=True)
    CE = cho_solve(factor, E.T)
    Cc = cho_solve(factor, c)
    CQ = cho_solve(factor, Q)
    return Capsule(
        _symmetric(A - E @ CE), h[retained] - E @ Cc,
        P - E @ CQ, _symmetric(Q.T @ CQ), b - Q.T @ Cc,
    )


def retract(capsule, rejected):
    """Jointly retract an identifier set from the original immutable capsule.

    Solves H = I - G[K,K] by Cholesky without forming its inverse.
    The output is the corrected retained information pair (S_K, t_K).
    Duplicate identifiers and their arrival order do not affect the result.
    """
    K = _ids(rejected, capsule.G.shape[0])
    if not K.size:
        return capsule.S.copy(), capsule.t.copy()
    H = np.eye(K.size) - capsule.G[np.ix_(K, K)]
    L = np.linalg.cholesky(H)
    W = solve_triangular(L, capsule.V[:, K].T, lower=True)
    w = solve_triangular(L, capsule.z[K], lower=True)
    return _symmetric(capsule.S - W.T @ W), capsule.t - W.T @ w


def posterior(S, t):
    """Return the retained mean and covariance by Cholesky solves."""
    factor = cho_factor(S, lower=True)
    return cho_solve(factor, t), cho_solve(factor, np.eye(S.shape[0]))


class Replica:
    """One epoch's capsule and grow-only rejection set.

    The caller obtains identifiers from a trusted validation mechanism.
    Network transport, authentication and epoch creation are outside this API.
    """
    def __init__(self, epoch, capsule):
        self.epoch = epoch
        self.capsule = capsule
        self.rejected = frozenset()

    def merge(self, epoch, rejected):
        """Merge an epoch-tagged rejection message and return canonical state."""
        if epoch != self.epoch:
            raise ValueError("Epoch mismatch")
        new_ids = _ids(rejected, self.capsule.G.shape[0])
        merged = self.rejected.union(new_ids.tolist())
        result = retract(self.capsule, merged)
        self.rejected = merged
        return result
