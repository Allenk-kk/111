"""Deterministic validation against full-model recomputation; no mission data."""
import json
from itertools import combinations

import numpy as np

from retraction import Replica, build_capsule, posterior, retract


def relative_error(actual, expected):
    return float(np.linalg.norm(actual - expected) / max(1.0, np.linalg.norm(expected)))


def main():
    rng = np.random.default_rng(20261001)
    n, q, d = 16, 8, 3
    retained = np.array([0, 2, 5, 9])
    A = rng.normal(size=(n, n))
    J0 = A.T @ A + 2.0 * np.eye(n)
    h0 = rng.normal(size=(n, d))
    U = 0.8 * rng.normal(size=(n, q))
    b = rng.normal(size=(q, d))
    J, h = J0 + U @ U.T, h0 + U @ b
    capsule = build_capsule(J, h, retained, U, b)
    max_error = {name: 0.0 for name in ("precision", "information", "mean", "covariance")}
    for k in range(q + 1):
        for K in combinations(range(q), k):
            remaining = np.setdiff1d(np.arange(q), K)
            # Reassemble from the trusted model and the factors that remain.
            J_gold = J0 + U[:, remaining] @ U[:, remaining].T
            h_gold = h0 + U[:, remaining] @ b[remaining]
            mu_gold = np.linalg.solve(J_gold, h_gold)[retained]
            cov_gold = np.linalg.solve(J_gold, np.eye(n))[np.ix_(retained, retained)]
            S_gold = np.linalg.solve(cov_gold, np.eye(retained.size))
            t_gold = S_gold @ mu_gold
            S, t = retract(capsule, K)
            mu, cov = posterior(S, t)
            for name, actual, expected in zip(max_error, (S, t, mu, cov), (S_gold, t_gold, mu_gold, cov_gold)):
                max_error[name] = max(max_error[name], relative_error(actual, expected))
                np.testing.assert_allclose(actual, expected, rtol=1e-10, atol=1e-10)
    epoch = 7
    expected = retract(capsule, range(q))
    for _ in range(20):
        replica = Replica(epoch, capsule)
        arrivals = rng.permutation(np.tile(np.arange(q), 3))
        for identifier in arrivals:
            result = replica.merge(epoch, [identifier])
        assert replica.rejected == frozenset(range(q))
        for actual, gold in zip(result, expected):
            np.testing.assert_allclose(actual, gold, rtol=1e-12, atol=1e-12)
    # Wrong epochs and unknown IDs must fail before modifying the rejection set.
    replica = Replica(epoch, capsule)
    replica.merge(epoch, [1, 1, 3])
    snapshot = replica.rejected
    for wrong_epoch, wrong_ids in ((epoch + 1, [2]), (epoch, [2, q]), (epoch, [-1])):
        try:
            replica.merge(wrong_epoch, wrong_ids)
        except ValueError:
            pass
        else:
            raise AssertionError("Invalid rejection was accepted")
        assert replica.rejected == snapshot
    # The same formulas reduce to direct factor deletion when no history exists.
    full_capsule = build_capsule(J, h, np.arange(n), U, b)
    S, t = retract(full_capsule, range(q))
    np.testing.assert_allclose(S, J0, rtol=1e-10, atol=1e-10)
    np.testing.assert_allclose(t, h0, rtol=1e-10, atol=1e-10)
    print(json.dumps({
        "seed": 20261001,
        "subsets_checked": 2 ** q,
        "duplicate_and_permuted_sequences_checked": 20,
        "max_relative_errors": max_error,
        "epoch_and_identifier_checks": "passed",
        "no_history_check": "passed",
        "status": "passed",
    }, indent=2))


if __name__ == "__main__":
    main()
